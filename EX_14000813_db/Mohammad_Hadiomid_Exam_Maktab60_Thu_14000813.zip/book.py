
import datetime
import pymongo
from mongo_service import Database
from bson.objectid import ObjectId
db = Database()

def create_book(book_data):
    try:
        book_entry = db.book_collection.insert_one(book_data)
        return book_entry.inserted_id
    except:
        print("Inserting Error Log Failed. Data:", book_data)
        pass
# validation?

def create_user(user_data):
    try:
        user_entry = db.user_collection.insert_one(user_data)
        # db.user_collection.create_index([('user_id', pymongo.ASCENDING)],
        #                                unique=True)
        return user_entry.inserted_id
    except:
        print("Inserting Error Log Failed. Data:", user_data)
        pass

def create_like_book(book_id, user_id): # uniqueness 
    db.book_collection.update_one({'_id': ObjectId(book_id}, {'$push' : {'likes': user_id}})

def delete_like_book(book_id, user_id):
    pipline = [
        {
            "$match": {"_id": book_id}
        }, {
            "$pull": {"like": user_id}
        }]
    result = db.book_collection.update(pipline)
    result.inserted_id
    print(db.user_collection.find())

def create_comment_book(book_id, user_id, comment):
    db.book_collection.update_one({'_id': book_id}, {'$push' : {'comment': {user_id : comment}}})

def get_all_books(tag=None): # order by like count - include only comment count
    # if tag is not none filter by tag
    db.book_collection.find()
    
    pipline = [
    {
        "$match": {"author": "Mike"}
    }, {
        "$project": {"count": {"$size": "$like"}}
    }]
    result = posts.aggregate(pipline)


def get_all_book_comments(book_id, count, index): # order by latest
   for book in book_collection.find({book_id: {count: 'comment'}}).sort("index"):
       print(book)

def get_all_user_liked_book(user_id):
    pass

def get_all_user_liked_and_taked_comment_book(user_id):
    pass

def get_books_tag_count():    
    pipline = [
    {
        "$match": {}
    }, {
        "$project": {"count": {"$size": "$tag"}}
    }]
    result = db.book_collection.aggregate(pipline)
    






book1 = {"title" : "Pymongo",
             "author": "Mike",
             "publication": "Nashreno",
             "tags": ["mongo", "db"],
             "published_date": datetime.datetime(2009, 11, 12, 11, 14)}

user1 = {"name" : "Mohammad",
         "pass": "123",
         "likes": []
             }


create_book(book1)
create_user(user1)
create_like_book(ObjectId('61838ec65072a7c5e2796475'), ObjectId('6183917b5072a7c5e2796477'))

db.book_collection.update_one({'_id': ObjectId('61839b2a5072a7c5e2796478')}, {'$push' : {'likes': ObjectId('61839d075072a7c5e279647a')}})
