# -*- coding: utf-8 -*-
"""
Created on Thu Nov  4 10:34:16 2021

@author: Lenovo
"""

import datetime
import pymongo
from mongo_service import Database
import unittest
import book


class Test(unittest.TestCase):
    ''' Test to work correctly '''

    def setUp(self):
        ''' Define db '''
        self.db = Database()




