# -*- coding: utf-8 -*-
"""
Created on Thu Nov  4  09:34:16 2021

@author: Mohammad - Hadiomid
"""
# =============================================================================
#   Exam - Model settings    (1400-08-13 - Thursday)
# =============================================================================

MONGO_HOST = "localhost"
MONGO_USER = ""
MONGO_PASS = ""
